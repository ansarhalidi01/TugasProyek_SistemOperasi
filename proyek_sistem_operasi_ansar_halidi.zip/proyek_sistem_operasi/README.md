# 🖥️ Proyek Sistem Operasi – Ansar Halidi

## 📘 Deskripsi
Proyek ini merupakan tugas mata kuliah **Sistem Operasi** yang bertujuan mempraktikkan perintah dasar Linux untuk mengelola file dan direktori.

---

## 🔧 Langkah-Langkah

### 1️⃣ Membuat Struktur Direktori
Perintah:
```bash
mkdir proyek_sistem_operasi
cd proyek_sistem_operasi
mkdir documents images archives logs
touch doc1.txt doc2.txt
```

### 2️⃣ Mengorganisasi File Berdasarkan Ekstensi
Gunakan `find`, `mv`, dan `cp` untuk memindahkan file:
```bash
mkdir sorted_files
find . -type f -name "*.txt" -exec mv {} sorted_files/ \;
find . -type f \( -name "*.jpg" -o -name "*.png" \) -exec cp {} sorted_files/ \;
```

### 3️⃣ Melakukan Pencarian File
```bash
find . -name "doc1.txt"
grep "log" -r documents/
```

### 4️⃣ Membuat Laporan Otomatis
```bash
echo "=== LAPORAN FILE SISTEM ===" > report.txt
find . -type f | wc -l >> report.txt
du -sh >> report.txt
ls -lhR >> report.txt
```

---

## 📊 Hasil Akhir
File laporan `report.txt` berisi:
- Jumlah file
- Ukuran direktori
- Daftar file dan detailnya

---

## 📸 Dokumentasi
Simpan screenshot hasil terminal di folder:
```
/images/
```

---

## 👨‍🎓 Identitas
- **Nama:** Ansar Halidi  
- **Mata Kuliah:** Sistem Operasi  
- **Dosen Pembimbing:** Zulhair Zidan Dj. Tamu  
