#!/bin/bash
# ============================================
# PROJECT: Sistem Operasi
# Nama   : Ansar Halidi
# Dosen  : Zulhair Zidan Dj. Tamu
# ============================================

echo "=== MEMBUAT STRUKTUR DIREKTORI ==="
mkdir -p proyek_sistem_operasi/{documents,images,archives,logs}
cd proyek_sistem_operasi
touch doc1.txt doc2.txt img1.jpg img2.png log1.txt

echo "=== MENGORGANISASI FILE ==="
mkdir -p sorted_files
find . -type f -name "*.txt" -exec mv {} sorted_files/ \;
find . -type f \( -name "*.jpg" -o -name "*.png" \) -exec cp {} sorted_files/ \;

echo "=== FUNGSI PENCARIAN ==="
find . -name "doc1.txt"
find . -size +1k
grep "log" -r documents/ || echo "Tidak ada kata 'log' di folder documents"

echo "=== MEMBUAT LAPORAN ==="
echo "=== LAPORAN FILE SISTEM ===" > report.txt
echo "Nama: Ansar Halidi" >> report.txt
echo "Mata Kuliah: Sistem Operasi" >> report.txt
echo "Dosen Pembimbing: Zulhair Zidan Dj. Tamu" >> report.txt
find . -type f | wc -l >> report.txt
du -sh >> report.txt
ls -lhR >> report.txt

echo "Proyek selesai! Laporan tersimpan di report.txt"
